function changeImage(imageSrc) {
    const largeImage = document.getElementById('largeImage');

    largeImage.classList.remove('show');

    setTimeout(() => {
        largeImage.src = imageSrc;
        largeImage.classList.add('show');
    }, 500); 
}
